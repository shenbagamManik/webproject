package com.poc.consentaggregator.api.Consentaggregator.Service;

import com.poc.consentaggregator.api.Consentaggregator.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}