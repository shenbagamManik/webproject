package com.kscodes.consentaggregator.model;

public class ActiveConsent {

	private String bankId;
	
	private String bankName;
	
	private String details;

	private String action;

	
	public ActiveConsent() {
		super();
	}


	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

	

	public String getDetails() {
		return details;
	}


	public void setDetails(String details) {
		this.details = details;
	}

	


}
