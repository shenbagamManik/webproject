library styles;

import 'package:flutter/material.dart';

class MeSuiteColors {
  static const green = const Color(0xFF0EE592);
  static const blue = const Color(0xFF3767B0);
}
