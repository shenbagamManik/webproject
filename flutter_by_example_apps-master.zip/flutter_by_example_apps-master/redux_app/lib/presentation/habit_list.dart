import 'package:flutter/material.dart';
import 'package:me_suite/models/habit.dart';

class HabitList extends StatelessWidget {
  final List<Habit> habits;

  HabitList(this.habits);

  @override
  Widget build(BuildContext context) {
    return new Container();
  }
}
