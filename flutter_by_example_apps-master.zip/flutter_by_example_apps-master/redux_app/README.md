# flutter_by_example redux_firebase

Flutter By Example is a tutorial site that walks through building a complete Flutter app.

**This repo simply holds the code needed to follow along with the repo.**

You can find more information at [flutterbyexample.com](https://flutterbyexample.com).

The Github for the Flutter By Example website can be found [here](https://github.com/ericwindmill/flutter_by_example_docs)


