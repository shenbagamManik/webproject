# We Rate Dogs
### They're Good Dogs, Brant.

Source Code for Flutter project used in the first section of [Flutter By Example](http://flutterbyexample.com).

[Flutter by Example](https://flutterbyexample.com) is an open source project that teaches one how to build [Flutter](https:flutter.io) mobile apps.

![preview app](http://res.cloudinary.com/ericwindmill/image/upload/c_scale,w_300/v1520698750/flutter_by_example/dogs_exmaple.gif)

### Usage 

You have to have flutter installed on your machine!

```bash
git clone https://github.com/ericwindmill/flutter_by_example_dogs_example.git
cd flutter_by_example_dogs_example
flutter packages get
flutter run
```
