# Night Sky Animation in Flutter

![sky animation gif](https://res.cloudinary.com/ericwindmill/image/upload/v1526854373/flutter_star_animation_hetibt.gif)