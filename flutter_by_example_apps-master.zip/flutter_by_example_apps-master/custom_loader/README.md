# Flutter custom loading screen

![gif of my thing](http://res.cloudinary.com/ericwindmill/image/upload/v1525022858/flutter_by_example/animation.gif)



Recreation of [this codepen](https://codepen.io/cassidoo/pen/KRdLvL)

![gif of codepen](http://res.cloudinary.com/ericwindmill/image/upload/c_scale,w_500/v1524935504/flutter_by_example/inspiration.gif)


