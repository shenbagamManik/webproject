import 'package:custom_loader/loading_screen.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(new MaterialApp(
    home: Scaffold(
      body: new BarLoadingScreen(),
    ),
  ));
}
