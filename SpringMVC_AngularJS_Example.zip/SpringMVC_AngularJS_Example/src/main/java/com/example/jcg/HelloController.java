package com.example.jcg;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HelloController
	{
	    @RequestMapping(value="/hello")
	    public ModelAndView hello()
	    {
	        return new ModelAndView("hello");
	    }
	    @RequestMapping(value="/login")
	    public ModelAndView login()
	    {
	        return new ModelAndView("login");
	    }
	    
	    @RequestMapping(value="/inversterview")
	    public ModelAndView inversterview()
	    {
	        return new ModelAndView("inversterview");
	    }
	    @RequestMapping(value="/details")
	    public ModelAndView details()
	    {
	        return new ModelAndView("details");
	    }
	    @RequestMapping(value="/userdetails",method=RequestMethod.GET,produces="application/json")
	    public UserDetails userdetails()
	    {
	        UserDetails userDetails = new UserDetails();
	        userDetails.setName("JCG");
	        userDetails.setDepartment("Angular");
	        
	        return userDetails;
	    }
	}
	


