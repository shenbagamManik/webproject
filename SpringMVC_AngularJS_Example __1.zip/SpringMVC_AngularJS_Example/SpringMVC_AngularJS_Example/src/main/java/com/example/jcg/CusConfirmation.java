package com.example.jcg;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CusConfirmation
{
    @XmlAttribute
    private boolean status;
   
    public CusConfirmation()
    {
        super();
    }
    public CusConfirmation(boolean status)
    {
        super();
        this.status = status;
        
    }
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
   
}
