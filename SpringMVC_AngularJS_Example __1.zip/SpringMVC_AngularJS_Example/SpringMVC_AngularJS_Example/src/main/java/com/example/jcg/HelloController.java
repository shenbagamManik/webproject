package com.example.jcg;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HelloController
	{
	    @RequestMapping(value="/hackathon")
	    public ModelAndView hackathon()
	    {
	        return new ModelAndView("hackathon");
	    }
	    @RequestMapping(value="/userdetails",method=RequestMethod.GET,produces="application/json")
	    public UserDetails userdetails()
	    {
	        UserDetails userDetails = new UserDetails();
	        userDetails.setName("JCG");
	        userDetails.setDepartment("Angular");
	        
	        return userDetails;
	    }
	    
	    @RequestMapping(value="/cusConfirmation",method=RequestMethod.GET,produces="application/json")
	    public CusConfirmation conDetails()
	    {
	    	CusConfirmation ccDetails = new CusConfirmation();
	    	ccDetails.setStatus(true);
	    	
	        return ccDetails;
	    }
	}
	


