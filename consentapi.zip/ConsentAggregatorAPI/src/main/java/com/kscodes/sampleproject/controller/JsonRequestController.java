package com.kscodes.sampleproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kscodes.sampleproject.model.ActiveConsent;
import com.kscodes.sampleproject.model.Employee;

@Controller
@RequestMapping(value = "/json")
public class JsonRequestController {

/*	@RequestMapping(value = "/consentdata", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody Employee postEmployeeData(@RequestBody Employee employee) {

		double newSalary = employee.getSalary() + 1000;
		employee.setFirstName("Shenbagam");
		employee.setLastName("Manikandan");
		employee.setId("13006");
		employee.setSalary(60000);
		//employee.setSalary(newSalary);

		return employee;
	}*/
	
	
	@RequestMapping(value = "/consentdata", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody ActiveConsent postEmployeeData(@RequestBody ActiveConsent activeConsent) {

		activeConsent.setBankId("101");
		activeConsent.setBankName("HGRT");
		activeConsent.setDetails("Home loan consent status is active for 4 accounts");
		activeConsent.setAction("Details");
		
		//employee.setSalary(newSalary);

		return activeConsent;
	}
	
	@RequestMapping(value = "/addEmployee")
	public String showEmployeePage(){
		return "addEmployee";
	}
	@RequestMapping(value = "/customerview")
	public String showCustomerPage(){
		return "customerview";
	}
		
			
}
